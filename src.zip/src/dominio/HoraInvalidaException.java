package dominio;

public class HoraInvalidaException extends Exception{
    
        public HoraInvalidaException (String msg){
        super(msg);
    }
}
