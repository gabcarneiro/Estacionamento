package dominio;

public class VagasEsgotadasException extends Exception{
    
        public VagasEsgotadasException(String msg){
        super(msg);
    }
}
